/*
  Movian HDOnline Plugin
  (c) 2016 Robert Nguyen All rights reserved
 */

var PREFIX = "hdo";
var page = require('showtime/page');
var io = require('native/io'); // XXX: Bad to require('native/')
var fs = require('native/fs'); // XXX: Bad to require('native/')
var http = require('showtime/http');
var html = require('showtime/html');
var utils = require('./lib/utils');
var api = require('./lib/api');
// global vars
var offset = 1; // current page in movie listing
var cacheMovies = {}; // global movie cache map, using URL path as key
var curPlaylist = []; // global episode playlist information

io.httpInspectorCreate(api.BASE_URL + '/.*', function(ctrl) {
  ctrl.setHeader('User-Agent', api.UA);
  ctrl.setHeader('Accept', 'application/json');
  ctrl.setHeader('Referer', api.BASE_URL);
  return 0;
});

// Create the service (ie, icon on home screen)
require('showtime/service').create("HDOnline", PREFIX + ":start", "video", true,
                                   Plugin.path + 'logo.png');

function listLoader(page, cat) {
  if (!offset) return false;
  page.loading = true;

  var result = api.htmlPage(cat, offset);
  if (result.movies) {
    for (var path in result.movies) {
      // caching new movie to global map
      cacheMovies[path] = result.movies[path];
      // add item to page
      page.appendItem(PREFIX + ':movie:' + path, 'video', {
        title: result.movies[path].title,
        description: result.movies[path].desc,
        icon: result.movies[path].image
      });
    }
  }

  page.loading = false;
  offset++;
  return result.pageCount && offset <= result.pageCount;
}

function videoPage(page, idx, path) {
  page.type = 'video';
  page.loading = true;
  
  var episode = api.episode(curPlaylist[idx]["vplugin.host"] + curPlaylist[idx].file + '&format=json');
  page.source = 'videoparams:' + JSON.stringify({
    title: curPlaylist[idx].title,
    icon: cacheMovies[path].image,
    description: cacheMovies[path].desc,
    no_fs_scan: true,
    no_subtitle_scan: true,
    canonicalUrl: PREFIX + ':video:' + idx + ':' + path,
    sources: episode.sources,
    subtitles: episode.subtitles
  });
  page.loading = false;
}

// Landing page
new page.Route(PREFIX + ":start", function(page) {
  page.type = 'directory';
  page.metadata.title = "HDOnline";

  page.appendItem("", "separator", {
    title: 'Phim Lẻ'
  });

  for (var cat in api.categories) {
    page.appendItem(PREFIX + ":category:" + cat, "directory", {
      title: api.categories[cat]
    });
  }

  page.appendItem("", "separator", {
    title: 'Phim Bộ'
  });

  for (cat in api.series_categories) {
    page.appendItem(PREFIX + ":category:" + cat, "directory", {
      title: api.series_categories[cat]
    });
  }
});

// Category page
new page.Route(PREFIX + ":category:(.*)", function(page, cat) {
  page.type = 'directory';
  page.metadata.title = api.categories[cat] || api.series_categories[cat];

  offset = 1;
  var paginator = listLoader.bind(null, page, cat);
  paginator();
  page.paginator = paginator;
});

// Movie page
new page.Route(PREFIX + ":movie:(.*)", function(page, path) {
  page.type = 'directory';
  page.loading = true;

  var resp = http.request(api.BASE_URL + '/' + path),
    content = resp.toString(),
    dom = html.parse(content),
    title = dom.root.getElementByClassName('tn-lockup-title')[0].textContent,
    playerCode;

  // legacy code
  if (content.indexOf('eval(') !== -1) {
    playerCode = utils.unpack(content.substring(content.indexOf('eval('), content.indexOf('jwplayer(player_id)')));
    playerCode = playerCode.substring(28, playerCode.length - 2);
  }
  // new code
  else {
    var begin = content.indexOf("jwplayer('hdoplayer').setup("),
        end = content.indexOf(");", begin);
    playerCode = content.substring(begin, end).substring(28);
    if (playerCode.length === 33) {
      begin = content.indexOf("var " + playerCode + " =") + 39;
      end = content.indexOf(';', begin);
      playerCode = content.substring(begin, end);
    }
  }

  // showtime.print(content);
  showtime.print(playerCode);
  curPlaylist = JSON.parse(playerCode).playlist;
  page.metadata.title = new showtime.RichText(title);

  if (curPlaylist.length > 1) {
    for (var i = 0; i < curPlaylist.length; i++) {
      page.appendItem(PREFIX + ':video:' + i + ':' + path, 'video', {
        title: curPlaylist[i].title,
        description: curPlaylist[i].description,
        icon: curPlaylist[i].image
      });
    }
  } else {
    videoPage(page, 0, path);
  }

  page.loading = false;
});

// Routes for video playback
new page.Route(PREFIX + ":video:([^:]*):(.*)", videoPage);
