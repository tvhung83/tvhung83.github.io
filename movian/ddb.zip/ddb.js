/*
 * Movian HDViet Plugin
 * (c) 2016 Robert Nguyen All rights reserved
 */

var PREFIX = "ddb";
var SEARCH_CACHE = 10;
var page = require('showtime/page');
var browse = require('./lib/browse');

var cache = require('showtime/store').create('ddb/cache');
// init recent search
if (!cache.recent) {
    cache.recent = [];
}

// Create the service (ie, icon on home screen)
require('showtime/service').create("Didibkk", PREFIX + ":start", "video", true,
                                   Plugin.path + 'logo.jpg');

// Landing page
new page.Route(PREFIX + ":start", function(page) {
    page.type = 'directory';
    page.metadata.title = "Didibkk";

    page.appendItem(PREFIX + ":search:", 'search', {
        title: 'Tìm kiếm'
    });
    if (cache.recent.length) {
        page.appendItem("", "separator", {
            title: SEARCH_CACHE + ' tìm kiếm gần nhất'
        });
        for (var i = 0; i < cache.recent.length; i++) {
            page.appendItem(PREFIX + ":search:" + cache.recent[i], "directory", {
                title: cache.recent[i]
            });
        }
    }

    page.appendItem("", "separator");

    for (var cat in browse.categories) {
        page.appendItem(PREFIX + ":category:" + cat, "directory", {
            title: browse.categories[cat]
        });
    }
});

// Search results
new page.Route(PREFIX + ":search:(.*)", function(page, query) {
    // caching 10 recent search
    if (cache.recent[0] != query) {
        if (cache.recent.indexOf(query) > -1) {
            cache.recent.splice(cache.recent.indexOf(query), 1);
        }
        cache.recent.unshift(query);
        cache.recent = cache.recent.slice(0, SEARCH_CACHE);
    }
    return browse.search(page, query, 1);
});

// Category page
new page.Route(PREFIX + ":category:(.*)", function(page, cat) {
    return browse.category(page, cat, 1);
});

// Movie page
new page.Route(PREFIX + ":movie:([^:]+):(.*)", browse.movie);

// TV Show page
new page.Route(PREFIX + ":tv:([^:]+):(.*)", browse.tv);

// Routes for video playback
new page.Route(PREFIX + ':video:([^:]+):(.*)', browse.videoPage);
