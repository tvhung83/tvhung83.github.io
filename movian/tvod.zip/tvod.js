/*
 * Movian Smartbox TVoD Plugin
 * (c) 2018 Robert Nguyen All rights reserved
 */

var PREFIX = "tv";
var UA = 'okhttp/3.8.0';
var API_KEY = 'oor2i3obujgy8eyaa854ar8r0gspmic0';
var AUTH = 'Bearer fXQdXBVQQctDSRVilWl2dkXIBY5kUE43';
var SEARCH_CACHE = 10;
var page = require('showtime/page');
var api = require('./lib/api');
var browse = require('./lib/browse');
var utils = require('./lib/utils');

require('native/io').httpInspectorCreate(api.BASE_URL + '/(category|content).*', function(ctrl) {
    ctrl.setHeader('User-Agent', UA);
    ctrl.setHeader('Authorization', AUTH);
    ctrl.setHeader('X-Api-Key', API_KEY);
    ctrl.setHeader('X-Language', 'vi');
    return 0;
});

var cache = require('showtime/store').create('tvod/cache');
// init recent search
if (!cache.recent) {
    cache.recent = [];
}
// init channels
if (!cache.channels) {
    cache.channels = api.getChannels();
}

// Create the service (ie, icon on home screen)
require('showtime/service').create("TVoD", PREFIX + ":start", "video", true,
                                   Plugin.path + 'logo.png');

// Landing page
new page.Route(PREFIX + ":start", function(page) {
    page.type = 'directory';
    page.metadata.title = "Smartbox TVoD";

    // page.appendItem(PREFIX + ":search:", 'search', {
    //     title: 'Tìm kiếm'
    // });

    // FIXME: put search inside each type
    // if (cache.recent.length) {
    //     page.appendItem("", "separator", {
    //         title: SEARCH_CACHE + ' tìm kiếm gần nhất'
    //     });
    //     for (var i = 0; i < cache.recent.length; i++) {
    //         page.appendItem(PREFIX + ":search:" + cache.recent[i], "directory", {
    //             title: cache.recent[i]
    //         });
    //     }
    // }

    page.appendItem(PREFIX + ":livetv", "directory", {
        title: 'Truyền Hình'
    });

    page.appendItem(PREFIX + ":tvod", "directory", {
        title: 'TH Xem Lại'
    });

    page.appendItem(PREFIX + ":type:1", "directory", {
        title: 'Phim'
    });

    page.appendItem(PREFIX + ":type:5", "directory", {
        title: 'Clip'
    });

    page.appendItem(PREFIX + ":type:3", "directory", {
        title: 'Ca nhạc'
    });

    page.appendItem(PREFIX + ":type:6", "directory", {
        title: 'Karaoke'
    });

    page.appendItem(PREFIX + ":type:7", "directory", {
        title: 'Radio'
    });
});

// Search results
// new page.Route(PREFIX + ":search:(.*)", function(page, query) {
//     // caching 10 recent search
//     if (cache.recent[0] != query) {
//         if (cache.recent.indexOf(query) > -1) {
//             cache.recent.splice(cache.recent.indexOf(query), 1);
//         }
//         cache.recent.unshift(query);
//         cache.recent = cache.recent.slice(0, SEARCH_CACHE);
//     }
//     return api.search(1, );
// });

// LiveTV page
new page.Route(PREFIX + ":livetv", function(page) {
    page.type = 'directory';
    page.metadata.title = 'Truyền Hình';
    for (var i = 0; i < cache.channels.length; i++) {
        var c = cache.channels[i];
        page.appendItem(PREFIX + ':view:' + c.id + ':' + utils.quality(c) + ':' + c.display_name, 'video', {
            title: c.display_name,
            icon: c.image
        });
    }
});

// TVoD page
new page.Route(PREFIX + ":tvod", function(page) {
    page.type = 'directory';
    page.metadata.title = 'TH Xem Lại';

    var channels = cache.channels.filter(function(c) {
        return c.is_catchup == 1;
    })

    for (var i = 0; i < channels.length; i++) {
        var c = channels[i];
        page.appendItem(PREFIX + ':tvod:' + c.id, 'directory', {
            title: c.display_name,
            icon: c.image
        });
    }
});

new page.Route(PREFIX + ":tvod:([0-9]+)", function(page, id) {
    page.type = 'directory';
    page.metadata.title = 'TH Xem Lại';

    var dates = api.getDates(id);
    for (var i = 0; i < dates.length; i++) {
        var d = dates[i];
        page.appendItem(PREFIX + ':tvod:' + id + ':' + d.datetime, 'directory', {
            title: d.datetime + ' | ' + d.day
        });
    }
});

new page.Route(PREFIX + ":tvod:([0-9]+):(.*)", function(page, id, date) {
    page.type = 'directory';
    page.metadata.title = 'TH Xem Lại';

    var programs = api.getPrograms(id, date);
    for (var i = 0; i < programs.length; i++) {
        var p = programs[i];
        var prefix = (p.status != 2) ? '(Chưa) ' : '';
        var start = utils.extract_time(p.started_at);
        page.appendItem(PREFIX + ':view:' + p.content_id + ':' + utils.quality(p) + ':' + p.name, 'video', {
            title: prefix + start + ' ' + p.name,
            description: p.name
        });
    }
});

// Type page
new page.Route(PREFIX + ":type:(.*)", function(page, type) {
    return browse.categories(page, type, 1);
});

// Items page
new page.Route(PREFIX + ":cat:([1-7]):([0-9]+):(.*)", function(page, type, id, title) {
    return browse.items(page, type, id, title, 1);
});

// Series page
new page.Route(PREFIX + ":episodes:(.*)", function(page, id) {
    return browse.episodes(page, id);
});

// Routes for video playback
new page.Route(PREFIX + ':view:([0-9]+):([1-5]):(.*)', browse.videoPage);
