/*
 * Movian HDViet Plugin
 * (c) 2016 Robert Nguyen All rights reserved
 */

var PREFIX = "vap";
var UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36 Edg/91.0.864.41';
var SEARCH_CACHE = 10;
var page = require('showtime/page');
var io = require('native/io'); // XXX: Bad to require('native/')
var api = require('./lib/api');
var browse = require('./lib/browse');
var categories = require('./lib/categories');

io.httpInspectorCreate(api.BASE_URL + '/.*', function(ctrl) {
    ctrl.setHeader('User-Agent', UA);
    return 0;
});

var cache = require('showtime/store').create('vap/cache');
// init recent search
if (!cache.recent) {
    cache.recent = [];
}

// Create the service (ie, icon on home screen)
require('showtime/service').create("Vaphim", PREFIX + ":start", "video", true,
                                   Plugin.path + 'logo.png');

// Landing page
new page.Route(PREFIX + ":start", function(page) {
    page.type = 'directory';
    page.metadata.title = "Vaphim";

    page.appendItem(PREFIX + ":search:", 'search', {
        title: 'Tìm kiếm'
    });

    if (cache.recent.length) {
        page.appendItem("", "separator", {
            title: SEARCH_CACHE + ' tìm kiếm gần nhất'
        });
        for (var i = 0; i < cache.recent.length; i++) {
            page.appendItem(PREFIX + ":search:" + cache.recent[i], "directory", {
                title: cache.recent[i]
            });
        }
    }

    page.appendItem("", "separator", {
        title: 'Phim Lẻ'
    });

    for (var cat in categories.movie) {
        page.appendItem(PREFIX + ":category:" + cat, "directory", {
            title: categories.movie[cat]
        });
    }

    page.appendItem("", "separator", {
        title: 'Phim Bộ'
    });

    for (cat in categories.tv) {
        page.appendItem(PREFIX + ":category:" + cat, "directory", {
            title: categories.tv[cat]
        });
    }
});

// Search results
new page.Route(PREFIX + ":search:(.*)", function(page, query) {
    // caching 10 recent search
    if (cache.recent[0] != query) {
        if (cache.recent.indexOf(query) > -1) {
            cache.recent.splice(cache.recent.indexOf(query), 1);
        }
        cache.recent.unshift(query);
        cache.recent = cache.recent.slice(0, SEARCH_CACHE);
    }
    return browse.search(page, { keyword: query, page: 1 });
});

// Category page
new page.Route(PREFIX + ":category:(.*)", function(page, cat) {
    return browse.category(page, cat, 1);
});

// Movie page
new page.Route(PREFIX + ":movie:([^\\|]+)\\|(.*)", browse.movie);

// Routes for video playback
new page.Route(PREFIX + ':video:([A-Z0-9]+):(.*)', browse.videoPage);
