/*
  Movian FPT Play Plugin
  (c) 2017 Robert Nguyen All rights reserved
 */

var PREFIX = "fpt";
var UA = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1'
var http = require('movian/http');
var XML = require('movian/xml');
var page = require('movian/page');
var io = require('native/io'); // XXX: Bad to require('native/')

var settings = require('movian/settings');

var plugin = JSON.parse(Plugin.manifest);
plugin.logo = Plugin.path + plugin.icon;

var api = require('./api');

var channels = require('showtime/store').create('channels');
if (!channels.map) {
  channels.map = api.getChannelMap();
}

settings.globalSettings(PREFIX, plugin.title, plugin.logo,
  plugin.title);

settings.createDivider("Authentication");
// settings.createString('phone', 'Phone');
// settings.createString('password', 'Password');

io.httpInspectorCreate('https://fptplay.net/show/.*', function(ctrl) {
  ctrl.setHeader('User-Agent', UA);
  ctrl.setHeader('Referer', 'https://fptplay.net');
  return 0;
});

var VOD = [
  {
    id: '5841458017dc130a9ab827d8',
    title: 'NỔI BẬT'
  },
  {
    id: '5841458f17dc130a9ab827da',
    title: 'HÀNH ĐỘNG'
  },
  {
    id: '584145a217dc130a98b82ac6',
    title: 'GIA ĐÌNH'
  },
  {
    id: '5841459a17dc130a9bb82644',
    title: 'HÀI HƯỚC'
  },
  {
    id: '584145b517dc130a9bb82647',
    title: 'KINH DỊ'
  },
  {
    id: '584145a717dc130a98b82ac8',
    title: 'TÂM LÝ'
  }
];

var SS = [
  {
    id: '557547a417dc1321ec85877b',
    title: 'PHIM BỘ HOT',
  },
  {
    id: '5575463917dc1321ec85876f',
    title: 'HOA NGỮ',
  },
  {
    id: '5575463017dc1321eb858658',
    title: 'HÀN QUỐC',
  },
  {
    id: '5575464417dc1321ee858668',
    title: 'VIỆT NAM',
  },
  {
    id: '5575467117dc1321ec858771',
    title: 'QUỐC GIA KHÁC',
  }
];

var TV = [
  {
    id: '5284724f169a585a2449c48d',
    title: 'REALITY SHOW'
  },
  {
    id: '52847259169a585a2449c48e',
    title: 'GAME SHOW'
  },
  {
    id: '52a812fdc9692822c05c5c52',
    title: 'TALK SHOW'
  },
  {
    id: '582ebf5f17dc13053a8e7b69',
    title: 'HOT CLIP'
  },
  {
    id: '584e249617dc136db3a0c909',
    title: 'LIVE SHOW'
  }
];

var ANIME = [
  {
    id: '578c8c5517dc1326a4b208a8',
    title: 'ANIME HOT'
  },
  {
    id: '5587c8ed17dc1353a2624a12',
    title: 'MÙA ĐÔNG 2017'
  },
  {
    id: '578c8c8817dc1326a5b202c6',
    title: 'HÀNH ĐỘNG'
  },
  {
    id: '578c8ca217dc1326a6b1ffbd',
    title: 'VIỄN TƯỞNG'
  },
  {
    id: '578c8cb017dc1326a3b1ff00',
    title: 'TÌNH CẢM'
  },
  {
    id: '578c8ccc17dc1326a3b1ff02',
    title: 'THỂ LOẠI KHÁC'
  }
];

var KID = [
  {
    id: '54fe562817dc136161a0cefc',
    title: 'HOẠT HÌNH'
  },
  {
    id: '57076a7117dc1331976d28bd',
    title: 'TIẾNG ANH'
  },
  {
    id: '54fe551717dc136164a0cf04',
    title: 'ÂM NHẠC'
  },
  {
    id: '54fe55a917dc136162a0cf65',
    title: 'CHƠI MÀ HỌC'
  },
];

var SPORT = [
  {
    id: '53e32bc5c969283fe55f5af9',
    title: 'WORLD CUP 2018'
  },
  {
    id: '5242528fc9692807f1cb31f3',
    title: 'BÓNG ĐÁ VIỆT NAM'
  },
  {
    id: '52427e49c9692807f1cb3266',
    title: 'CÁC MÔN THỂ THAO KHÁC'
  }
];

var AUDIO = [
  {
    id: '5734055817dc136987844b7c',
    title: 'TRUYỆN VĂN HỌC'
  },
  {
    id: '573404a117dc136988844b94',
    title: 'TRUYỆN CỔ TÍCH'
  }
];

var offset = 1; // current page in movie listing

function oprint(o) {
  // print an object, this should really be a Movian builtin
  print(JSON.stringify(o, null, 4));
}

function fmt(date) {
  var d = date.getDate(),
      m = date.getMonth() + 1,
      y = date.getFullYear();
  return (d < 10 ? '0' + d : d) + '-' + (m < 10 ? '0' + m : m) + '-' + y;
}

function listLoader(page, channel, cur) {
  page.loading = true;

  cur.setDate(cur.getDate() - offset);
  var date = fmt(cur);
  page.appendItem(null, 'separator', {
    title: date
  });
  
  var url = 'https://fptplay.net/show/schedule?channel=' + channel + '&date=' + date + '&channel_now=';
  var xml = XML.parse(http.request(url).toString().replace(/style=height:\d+px /g, ''));
  if (xml.length > 1) {
    for (var i = xml.length - 1; i >= 0; i--) {
      var id = xml[i]["@onclick"].match(/'([^']+)'/)[1],
          time = xml[i].a[0].p,
          type = xml[i].a[1][0],
          name = xml[i].a[1][1];
      page.appendItem(PREFIX + ':tvod:' + id, 'video', {
        title: time + ' - ' + type,
        description: name || ''
      });
    }
  }

  page.loading = false;
  offset++;
  return xml.length > 1;
}


function vodLoader(page, cat) {
  if (!offset) return false;
  page.loading = true;

  var result = api.getVODs(cat, offset);
  result.forEach(function(m) {
    page.appendItem(PREFIX + ':vod:ep:' + m.id + ':' + m.title, 'video', {
      title: m.title,
      icon: m.icon
    });
  });
  page.loading = false;
  offset++;
  return result.length > 0;
}


function epLoader(page, id) {
  if (!offset) return false;
  page.loading = true;

  var result = api.getEps(id, offset);
  result.forEach(function (m) {
    if (m) {
      page.appendItem(PREFIX + ':vod:view:' + id + ':' + m.ep, 'video', {
        title: m.title,
        icon: m.icon
      });
    }
  });
  page.loading = false;
  offset++;
  return result.length > 0;
}


// Create the service (ie, icon on home screen)
require('showtime/service').create(plugin.title, PREFIX + ":start", "video", true,
  plugin.logo);


// Landing page
new page.Route(PREFIX + ":start", function (page) {
  http.request("https://fptplay.net/user/login", {
    headers: {
      'X-Requested-With': 'XMLHttpRequest'
    },
    postdata: {
      phone: '0913977511',
      password: '123456'
    }
  });
  page.type = 'directory';
  page.metadata.title = "FPT Play";
  page.metadata.icon = Plugin.path + 'fpt-play.png';
  page.appendItem(PREFIX + ':live:home', 'directory', {
    title: 'LiveTV',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':live:home'
  });

  page.appendItem(PREFIX + ':sched:home', 'directory', {
    title: 'TVOD',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':sched:home'
  });

  page.appendItem(PREFIX + ':vod:home', 'directory', {
    title: 'Phim Lẻ',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':vod:home'
  });

  page.appendItem(PREFIX + ':ss:home', 'directory', {
    title: 'Phim Bộ',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':ss:home'
  });

  page.appendItem(PREFIX + ':tv:home', 'directory', {
    title: 'TV Show',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':tv:home'
  });

  page.appendItem(PREFIX + ':anime:home', 'directory', {
    title: 'Anime',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':anime:home'
  });

  page.appendItem(PREFIX + ':kid:home', 'directory', {
    title: 'Thiếu Nhi',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':kid:home'
  });

  page.appendItem(PREFIX + ':sport:home', 'directory', {
    title: 'Thể Thao',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':sport:home'
  });

  page.appendItem(PREFIX + ':audio:home', 'directory', {
    title: 'Truyện Audio',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':audio:home'
  });
});


new page.Route(PREFIX + ":live:home", function (page) {
  page.type = 'directory';
  page.metadata.title = 'Live TV';
  for (var id in channels.map) {
    page.appendItem(PREFIX + ':live:' + id, 'video', {
      title: channels.map[id].title,
      icon: channels.map[id].icon
    });
  }
});


new page.Route(PREFIX + ":live:(.*)", function (page, id) {
  page.loading = true;
  api.call("getlinklivetv", {
    headers: {
      'X-Requested-With': 'XMLHttpRequest'
    },
    postdata: {
      id: id,
      type: 'newchannel',
      quality: 3,
      mobile: 'web'
    }
  }, page, function(info) {
    page.type = 'video';
    var videoParams = {
      title: unescape(info.name),
      icon: info.thumb,
      canonicalUrl: PREFIX + ':live:' + info._id,
      sources: [{
        url: info.stream
      }],
      no_subtitle_scan: 1
    }
    page.source = 'videoparams:' + JSON.stringify(videoParams);
  });
});


new page.Route(PREFIX + ":sched:home", function (page) {
  page.metadata.title = 'TVOD';
  page.type = 'directory';
  for (var id in channels.map) {
    if (channels.map[id].isTimeshift) {
      page.appendItem(PREFIX + ':sched:' + id, 'directory', {
        title: channels.map[id].title,
        icon: channels.map[id].icon
      });
    }
  }
});


new page.Route(PREFIX + ":sched:(.*)", function (page, id) {
  page.metadata.title = channels.map[id].title;
  page.type = 'directory';
  offset = 0;
  var paginator = listLoader.bind(null, page, id, new Date());
  paginator();
  page.paginator = paginator;
});


new page.Route(PREFIX + ":tvod:(.*)", function (page, id) {
  page.loading = true;
  api.timeshift(id, page);
});


new page.Route(PREFIX + ":vod:home", function (page, cat) {
  page.metadata.title = 'Phim Lẻ';
  page.type = 'directory';
  VOD.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":ss:home", function (page, cat) {
  page.metadata.title = 'Phim Bộ';
  page.type = 'directory';
  SS.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":tv:home", function (page, cat) {
  page.metadata.title = 'TV Show';
  page.type = 'directory';
  TV.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":anime:home", function (page, cat) {
  page.metadata.title = 'Anime';
  page.type = 'directory';
  ANIME.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":kid:home", function (page, cat) {
  page.metadata.title = 'Thiếu Nhi';
  page.type = 'directory';
  KID.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":sport:home", function (page, cat) {
  page.metadata.title = 'Thể Thao';
  page.type = 'directory';
  SPORT.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":audio:home", function (page, cat) {
  page.metadata.title = 'Truyện Audio';
  page.type = 'directory';
  AUDIO.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":vod:list:([^:]+):(.*)", function (page, cat, title) {
  page.metadata.title = title;
  page.type = 'directory';
  offset = 1;
  var paginator = vodLoader.bind(null, page, cat);
  paginator();
  page.paginator = paginator;
});


new page.Route(PREFIX + ":vod:ep:([^:]+):(.*)", function (page, id, title) {
  page.metadata.title = title;
  page.type = 'directory';
  offset = 1;
  var paginator = epLoader.bind(null, page, id);
  paginator();
  page.paginator = paginator;
});


new page.Route(PREFIX + ":vod:view:([^:]+):(.*)", function (page, id, episode) {
  page.loading = true;
  api.getVOD(id, episode, page);
});
