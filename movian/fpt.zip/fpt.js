/*
  Movian FPT Play Plugin
  (c) 2017 Robert Nguyen All rights reserved
 */

var PREFIX = "fpt";
var UA = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1';
var http = require('movian/http');
var XML = require('movian/xml');
var page = require('movian/page');
var io = require('native/io'); // XXX: Bad to require('native/')
var store = require('movian/store');
var popup = require('movian/popup');

var settings = require('movian/settings');

var plugin = JSON.parse(Plugin.manifest);
plugin.logo = Plugin.path + plugin.icon;

var api = require('./api');
var utils = require('./utils');

var channels = store.create('channels');
if (!channels.map) {
  channels.map = api.getChannelMap();
}
var cookies = store.create('cookies');


settings.globalSettings(PREFIX, plugin.title, plugin.logo, plugin.title);

var PHONE = '', PASSWORD = '';
settings.createDivider("Account");
settings.createString('phone', 'Phone', PHONE, function(v) { PHONE = v; });
settings.createString('password', 'Password', PASSWORD, function(v) { PASSWORD = v; });

function ensureLogin() {
  var resp = api.login(PHONE, PASSWORD);
  console.log('login >>> ');
  console.log(resp.statuscode);
  cookies = utils.serialCookies(resp);
  console.log(cookies);
  if (!api.isSignedIn()) {
    resp = api.resetDevices(PHONE, PASSWORD, cookies.token);
    console.log('reset >>> ' + resp.toString());
    console.log(resp.multiheaders_lc);
    cookies = utils.serialCookies(resp);
  }
}

settings.createDivider('Actions');


settings.createAction('login_bt', 'Login', function() {
  ensureLogin();
  popup.notify('Login: ' + (api.isSignedIn() ? 'suceeded' : 'failed'));
});


settings.createAction('reset', 'Reset', function() {
  delete cookies.laravel_id;
  delete cookies.laravel_session;
  delete cookies.token;
  delete channels.map;
});


settings.createAction('reset_devices_bt', 'Reset Devices', function() {
  var resp = api.resetDevices(PHONE, PASSWORD);
  console.log('reset >>> ');
  console.log(resp.multiheaders_lc);
  cookies = utils.serialCookies(resp);
});


io.httpInspectorCreate('https://fptplay.vn/.*', function(ctrl) {
  ctrl.setHeader('User-Agent', UA);
  ctrl.setHeader('Referer', 'https://fptplay.vn');
  return 0;
});

io.httpInspectorCreate('https://tshift.fptplay.net/.*', function(ctrl) {
  ctrl.setHeader('User-Agent', UA);
  ctrl.setHeader('Referer', 'https://tshift.fptplay.net/');
  return 0;
});


var VOD = [
  {
    id: '5841458017dc130a9ab827d8',
    title: 'Nổi Bật'
  },
  {
    id: '5841458f17dc130a9ab827da',
    title: 'Hành Động'
  },
  {
    id: '584145a217dc130a98b82ac6',
    title: 'Gia Đình'
  },
  {
    id: '5841459a17dc130a9bb82644',
    title: 'Hài Hước'
  },
  {
    id: '584145b517dc130a9bb82647',
    title: 'Kinh Dị'
  },
  {
    id: '584145a717dc130a98b82ac8',
    title: 'Tâm Lý'
  }
];

var SS = [
  {
    id: '557547a417dc1321ec85877b',
    title: 'Phim Bộ Hot'
  },
  {
    id: '5575463917dc1321ec85876f',
    title: 'Hoa Ngữ'
  },
  {
    id: '5575463017dc1321eb858658',
    title: 'Hàn Quốc'
  },
  {
    id: '5575464417dc1321ee858668',
    title: 'Việt Nam'
  },
  {
    id: '5575467117dc1321ec858771',
    title: 'Quốc Gia Khác'
  }
];

var TV = [
  {
    id: '5284724f169a585a2449c48d',
    title: 'Reality Show'
  },
  {
    id: '52847259169a585a2449c48e',
    title: 'Game Show'
  },
  {
    id: '52a812fdc9692822c05c5c52',
    title: 'Talk Show'
  },
  {
    id: '582ebf5f17dc13053a8e7b69',
    title: 'Hot Clip'
  },
  {
    id: '584e249617dc136db3a0c909',
    title: 'LIVE SHOW'
  }
];

var ANIME = [
  {
    id: '578c8c5517dc1326a4b208a8',
    title: 'Anime Hot'
  },
  {
    id: '5587c8ed17dc1353a2624a12',
    title: 'Mùa Đông 2017'
  },
  {
    id: '578c8c8817dc1326a5b202c6',
    title: 'Hành Động'
  },
  {
    id: '578c8ca217dc1326a6b1ffbd',
    title: 'Viễn Tưởng'
  },
  {
    id: '578c8cb017dc1326a3b1ff00',
    title: 'Tình Cảm'
  },
  {
    id: '578c8ccc17dc1326a3b1ff02',
    title: 'Thể Loại Khác'
  }
];

var KID = [
  {
    id: '54fe562817dc136161a0cefc',
    title: 'Hoạt Hình'
  },
  {
    id: '57076a7117dc1331976d28bd',
    title: 'Tiếng Anh'
  },
  {
    id: '54fe551717dc136164a0cf04',
    title: 'Âm Nhạc'
  },
  {
    id: '54fe55a917dc136162a0cf65',
    title: 'Chơi Mà Học'
  },
];

var SPORT = [
  {
    id: '53e32bc5c969283fe55f5af9',
    title: 'World Cup 2018'
  },
  {
    id: '5242528fc9692807f1cb31f3',
    title: 'Bóng Đá Việt Nam'
  },
  {
    id: '52427e49c9692807f1cb3266',
    title: 'Các Môn Thể Thao Khác'
  }
];

var AUDIO = [
  {
    id: '5734055817dc136987844b7c',
    title: 'Truyện Văn Học'
  },
  {
    id: '573404a117dc136988844b94',
    title: 'Truyện Cổ Tích'
  }
];

var offset = 1; // current page in movie listing

function oprint(o) {
  // print an object, this should really be a Movian builtin
  print(JSON.stringify(o, null, 4));
}

function fmt(date) {
  var d = date.getDate(),
      m = date.getMonth() + 1,
      y = date.getFullYear();
  return (d < 10 ? '0' + d : d) + '-' + (m < 10 ? '0' + m : m) + '-' + y;
}

function listLoader(page, channel, cur) {
  page.loading = true;

  cur.setDate(cur.getDate() - offset);
  var date = fmt(cur);
  page.appendItem(null, 'separator', {
    title: date
  });
  
  var url = 'https://fptplay.vn/show/schedule?channel=' + channel + '&date=' + date + '&channel_now=';
  var xml = XML.parse(http.request(url).toString().replace(/style=height:\d+px /g, ''));
  if (xml.length > 1) {
    for (var i = xml.length - 1; i >= 0; i--) {
      var id = xml[i]["@onclick"].match(/'([^']+)'/)[1],
          time = xml[i].a[0].p,
          type = xml[i].a[1][0],
          name = xml[i].a[1][1];
      page.appendItem(PREFIX + ':tvod:' + id, 'video', {
        title: time + ' - ' + type,
        description: name || ''
      });
    }
  }

  page.loading = false;
  offset++;
  return xml.length > 1;
}


function vodLoader(page, cat) {
  if (!offset) return false;
  page.loading = true;

  var result = api.getVODs(cat, offset);
  result.forEach(function(m) {
    page.appendItem(PREFIX + ':vod:ep:' + m.id + ':' + m.title, 'video', {
      title: m.title,
      icon: m.icon
    });
  });
  page.loading = false;
  offset++;
  return result.length > 0;
}


function epLoader(page, id) {
  if (!offset) return false;
  page.loading = true;

  // var result = api.getEps(id, offset);
  // result.forEach(function(m) {
  //   page.appendItem(PREFIX + ':vod:ep:' + m.id + ':' + m.title, 'video', {
  //     title: m.title,
  //     icon: m.icon
  //   });
  // });
  var result = api.getEps(page, id, offset);
  // result.forEach(function(ep) {
  //     page.appendItem(PREFIX + ':vod:view:' + id + ':' + ep, 'video', {
  //       title: ep.title,
  //       icon: ep.icon
  //     });
  // });
  offset++;
  return result && result.length > 0;
}


// Create the service (ie, icon on home screen)
require('showtime/service').create(plugin.title, PREFIX + ":start", "video", true,
  plugin.logo);


// Landing page
new page.Route(PREFIX + ":start", function (page) {
  page.type = 'directory';
  page.metadata.title = "FPT Play";
  page.metadata.icon = Plugin.path + 'fpt-play.png';
  page.appendItem(PREFIX + ':live:home', 'directory', {
    title: 'LiveTV',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':live:home'
  });

  page.appendItem(PREFIX + ':sched:home', 'directory', {
    title: 'TVOD',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':sched:home'
  });

  page.appendItem(PREFIX + ':vod:home', 'directory', {
    title: 'Phim Lẻ',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':vod:home'
  });

  page.appendItem(PREFIX + ':ss:home', 'directory', {
    title: 'Phim Bộ',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':ss:home'
  });

  page.appendItem(PREFIX + ':tv:home', 'directory', {
    title: 'TV Show',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':tv:home'
  });

  page.appendItem(PREFIX + ':anime:home', 'directory', {
    title: 'Anime',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':anime:home'
  });

  page.appendItem(PREFIX + ':kid:home', 'directory', {
    title: 'Thiếu Nhi',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':kid:home'
  });

  page.appendItem(PREFIX + ':sport:home', 'directory', {
    title: 'Thể Thao',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':sport:home'
  });

  page.appendItem(PREFIX + ':audio:home', 'directory', {
    title: 'Truyện Audio',
    icon: plugin.logo,
    canonicalUrl: PREFIX + ':audio:home'
  });
});


new page.Route(PREFIX + ":live:home", function (page) {
  page.type = 'directory';
  page.metadata.title = 'Live TV';
  for (var id in channels.map) {
    page.appendItem(PREFIX + ':live:' + id, 'video', {
      title: channels.map[id].title,
      icon: channels.map[id].icon
    });
  }
});


new page.Route(PREFIX + ":live:(.*)", function (page, id) {
  page.loading = true;
  page.type = 'video';
  api.getLiveTV(page, id);
});


new page.Route(PREFIX + ":sched:home", function (page) {
  page.metadata.title = 'TVOD';
  page.type = 'directory';
  for (var id in channels.map) {
    if (channels.map[id].isTimeshift) {
      page.appendItem(PREFIX + ':sched:' + id, 'directory', {
        title: channels.map[id].title,
        icon: channels.map[id].icon
      });
    }
  }
});


new page.Route(PREFIX + ":sched:(.*)", function (page, id) {
  page.metadata.title = channels.map[id].title;
  page.type = 'directory';
  offset = 0;
  var paginator = listLoader.bind(null, page, id, new Date());
  paginator();
  page.paginator = paginator;
});


new page.Route(PREFIX + ":tvod:(.*)", function (page, id) {
  page.loading = true;
  api.timeshift(id, page);
});


new page.Route(PREFIX + ":vod:home", function (page, cat) {
  page.metadata.title = 'Phim Lẻ';
  page.type = 'directory';
  VOD.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":ss:home", function (page, cat) {
  page.metadata.title = 'Phim Bộ';
  page.type = 'directory';
  SS.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":tv:home", function (page, cat) {
  page.metadata.title = 'TV Show';
  page.type = 'directory';
  TV.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":anime:home", function (page, cat) {
  page.metadata.title = 'Anime';
  page.type = 'directory';
  ANIME.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":kid:home", function (page, cat) {
  page.metadata.title = 'Thiếu Nhi';
  page.type = 'directory';
  KID.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":sport:home", function (page, cat) {
  page.metadata.title = 'Thể Thao';
  page.type = 'directory';
  SPORT.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":audio:home", function (page, cat) {
  page.metadata.title = 'Truyện Audio';
  page.type = 'directory';
  AUDIO.forEach(function(cat) {
    page.appendItem(PREFIX + ':vod:list:' + cat.id + ':' + cat.title, 'directory', {
      title: cat.title
    });
  })
});


new page.Route(PREFIX + ":vod:list:([^:]+):(.*)", function (page, cat, title) {
  page.metadata.title = title;
  page.type = 'directory';
  offset = 1;
  var paginator = vodLoader.bind(null, page, cat);
  paginator();
  page.paginator = paginator;
});


new page.Route(PREFIX + ":vod:ep:([^:]+):(.*)", function (page, id, title) {
  page.metadata.title = title;
  page.type = 'directory';
  offset = 1;
  var paginator = epLoader.bind(null, page, id);
  paginator();
  page.paginator = paginator;
});


new page.Route(PREFIX + ":vod:view:([^:]+):(.*)", function (page, id, episode) {
  page.loading = true;
  api.getVOD(id, episode, page);
});

new page.Route(PREFIX + ":test", function(page) {
  console.log(page);
  print('Signed In? >>> ' + api.isSignedIn());
});
