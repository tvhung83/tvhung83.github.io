exports.serialCookies = function(resp) {
  var cookies = require('movian/store').create('cookies');
  if (resp.multiheaders_lc['set-cookie']) {
    var arr = resp.multiheaders_lc['set-cookie'];
    for (var i = 0; i < arr.length; i++) {
      var matches = arr[i].match(/([^=]+)=([^;]+)/i);
      console.log('setting: ' + matches[1] + ' >> ' + matches[2]);
      cookies[matches[1]] = matches[2];
    }
  }
  return cookies;
}

exports.marshallCookies = function(cookies) {
  var str = '';
  var allowed_keys = ['laravel_id', 'laravel_session', 'token'];
  for (var i = 0; i < allowed_keys.length; i++) {
    var key = allowed_keys[i];
    if (cookies[key]) {
      str += key + '=' + cookies[key] + '; ';
    }
  }
  return str;
}
