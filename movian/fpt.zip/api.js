var http = require('movian/http');
var html = require('showtime/html');

var parseJSON = function(result, page) {
  var r = JSON.parse(result);
  if(r.error) {
    console.error("Request failed: " + URL);
    console.error(r.error.errors[0].message);
    if(page) page.error(r.error.errors[0].reason);
    throw(new Error("Request failed: " + r.error.errors[0].reason));
  }
  return r;
};


exports.BASE_URL = 'https://fptplay.vn';
exports.call = function(endpoint, params, page, cb) {
  var URL = exports.BASE_URL + '/show/' + endpoint;

  http.request(URL, params, function(err, result) {
    if(page) page.loading = false;
    if(err) {
      if(page) page.error(err);
    } else {
      try {
        cb(result);
      } catch(e) {
        if(page) page.error(e);
        throw(e);
      }
    }
  });
};


exports.isSignedIn = function() {
  var cookies = store.create('cookies');
  if (!cookies.laravel_session) {
    return false;
  }
  return http.request(exports.BASE_URL + '/login', {
    headers: {
      'Cookie': 'laravel_session=' + cookies.laravel_session
    }
  }).statuscode == 302;  
};


exports.login = function(phone, password) {
  return http.request(exports.BASE_URL + '/user/login', {
    postdata: {
      phone: phone,
      password: password
    }
  });
};


exports.logout = function() {
  http.request(exports.BASE_URL + '/user/logout');
};


exports.resetDevices = function(phone, password, token) {
  return http.request(exports.BASE_URL + '/tai-khoan/xoa-tat-ca-web', {
    headers: {
      'Cookie': 'token=' + token
    },
    postdata: {
      phone: phone,
      password: password
    }
  });
};


exports.confirmResetDevices = function(code, phone, password) {
  http.request(exports.BASE_URL + '/tai-khoan/xac-nhan-reset-thiet-bi', {
    headers: {
      'X-Requested-With': 'XMLHttpRequest'
    },
    postdata: {
      otpCode: code,
      phone: phone,
      password: password,
      country_code: 'VN'
    }
  });
};


exports.getChannelMap = function() {
  var dom = html.parse(http.request(exports.BASE_URL + '/livetv')),
    channels = dom.root.getElementByClassName('tv_channel'),
    tsChannels = dom.root.getElementByClassName('timeshift_channel').map(function(p) {
      return p.textContent;
    });
  
  return channels.reduce(function (map, ch) {
    var href = (ch.attributes.getNamedItem('data-href') || ch.attributes.getNamedItem('href')).value,
        dashes = href.split('/'),
        id = dashes[dashes.length - 1],
        title = ch.attributes.getNamedItem('title').value,
        image = ch.getElementByTagName('img')[0].attributes.getNamedItem('data-original').value,
        icon = image.substr(0, image.indexOf('?'));
    map[id] = { id: id, title: title, icon: icon, isTimeshift: tsChannels.indexOf(title) > -1 };
    return map;
  }, {});
};


exports.getLiveTV = function(page, ch) {
  exports.call("getlinklivetv", {
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'Cookie': 'laravel_session=eyJpdiI6InlEd1wvZ1Rmdmd1VG9HTllEcE5majhBPT0iLCJ2YWx1ZSI6InN1V1BiWHRvWjZNd3pUNVdldGNpXC9MZlhIWllqY2dPSjhhZkUxcU5zSm1GdWdETVdhc0pTUkJuK0VuXC93a0xDT3RwUldDTVV5aTJEWENHZVlxUUVaZmc9PSIsIm1hYyI6IjNhZDNiMDNmYzYzMzEzODVmYThkMTIzNDkxM2U3Njg3ZmFjZTViM2UwZDM4NzRmNTFlMGUwOWRiOWJjMDQ0ZTkifQ%3D%3D;'
    },
    postdata: {
      id: ch,
      type: 'newchannel',
      quality: 3,
      mobile: 'web'
    }
  }, page, function(result) {
    page.loading = false;
    var info = parseJSON(result);
    var videoParams = {
      title: unescape(info.name),
      icon: info.thumb,
      canonicalUrl: PREFIX + ':live:' + info._id,
      sources: [{
        url: info.stream
      }],
      no_subtitle_scan: true,
      subtitles: []
    };
    page.source = 'videoparams:' + JSON.stringify(videoParams);
  });
};

exports.timeshift = function(id, page) {
  exports.call("timeshift", {
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'Cookie': 'laravel_session=eyJpdiI6InlEd1wvZ1Rmdmd1VG9HTllEcE5majhBPT0iLCJ2YWx1ZSI6InN1V1BiWHRvWjZNd3pUNVdldGNpXC9MZlhIWllqY2dPSjhhZkUxcU5zSm1GdWdETVdhc0pTUkJuK0VuXC93a0xDT3RwUldDTVV5aTJEWENHZVlxUUVaZmc9PSIsIm1hYyI6IjNhZDNiMDNmYzYzMzEzODVmYThkMTIzNDkxM2U3Njg3ZmFjZTViM2UwZDM4NzRmNTFlMGUwOWRiOWJjMDQ0ZTkifQ%3D%3D;'
    },
    postdata: {
      id: id,
      stream_id: 'bitrate_1000'
    }
  }, page, function(result) {
    var info = parseJSON(result);
    page.loading = false;
    page.type = 'video';
    // var playlist = http.request(info.stream).toString().split("\n");
    // var urls = [];
    // for (var i = 0; i < playlist.length; i++) {
    //   var matches = playlist[i].match(/BANDWIDTH=(\d+)/i);
    //   if (matches) {
    //     urls.push({
    //       bitrate: matches[1],
    //       mimetype: 'application/vnd.apple.mpegurl',
    //       url: info.stream.substr(0, info.stream.lastIndexOf('/') + 1) + playlist[i+1]
    //     });
    //     i++;
    //   }
    // }
    // console.log(urls);
    var videoParams = {
      // title: unescape(info.name),
      canonicalUrl: PREFIX + ':tvod:' + id,
      // sources: urls,
      sources: [ { url: info.stream }],
      no_subtitle_scan: 1
    };
    page.source = 'videoparams:' + JSON.stringify(videoParams);
    // print(page.source);
  });
};


exports.getVODs = function(catId, p) {
  var dom = html.parse(http.request(exports.BASE_URL + '/show/more',
    {
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'Cookie': 'laravel_session=eyJpdiI6InlEd1wvZ1Rmdmd1VG9HTllEcE5majhBPT0iLCJ2YWx1ZSI6InN1V1BiWHRvWjZNd3pUNVdldGNpXC9MZlhIWllqY2dPSjhhZkUxcU5zSm1GdWdETVdhc0pTUkJuK0VuXC93a0xDT3RwUldDTVV5aTJEWENHZVlxUUVaZmc9PSIsIm1hYyI6IjNhZDNiMDNmYzYzMzEzODVmYThkMTIzNDkxM2U3Njg3ZmFjZTViM2UwZDM4NzRmNTFlMGUwOWRiOWJjMDQ0ZTkifQ%3D%3D;'
      },
      postdata: {
        stucture_id: catId,
        type: 'new',
        page: p
      }
    })),
    movies = dom.root.getElementByTagName('a');

  return movies.map(function (a) {
    var href = a.attributes.getNamedItem('href').value,
        id = href.substring(href.lastIndexOf('-') + 1, href.lastIndexOf('.')),
        img = a.getElementByTagName('img')[0],
        title = img.attributes.getNamedItem('title').value,
        image = img.attributes.getNamedItem('src').value,
        icon = image.substr(0, image.indexOf('?'));
    return { id: id, title: title, icon: icon };
  });
};


exports.getEps = function(page, id, p) {
  console.log('Getting eps: id = ' + id + ', p = ' + p);
  exports.call("episode",
  {
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'Cookie': 'laravel_session=eyJpdiI6InlEd1wvZ1Rmdmd1VG9HTllEcE5majhBPT0iLCJ2YWx1ZSI6InN1V1BiWHRvWjZNd3pUNVdldGNpXC9MZlhIWllqY2dPSjhhZkUxcU5zSm1GdWdETVdhc0pTUkJuK0VuXC93a0xDT3RwUldDTVV5aTJEWENHZVlxUUVaZmc9PSIsIm1hYyI6IjNhZDNiMDNmYzYzMzEzODVmYThkMTIzNDkxM2U3Njg3ZmFjZTViM2UwZDM4NzRmNTFlMGUwOWRiOWJjMDQ0ZTkifQ%3D%3D;'
    },
    postdata: {
      film_id: id,
      page: p
    }
  }, page, function(result) {
    page.loading = false;
    try {
      var dom = html.parse(result);
      return dom.root.getElementByTagName('li').map(function (li) {
        if (li.attributes.getNamedItem('rol')) {
          var ep = li.attributes.getNamedItem('rol').value,
              a = li.getElementByTagName('a')[0],
              img = li.getElementByTagName('img')[0],
              title = a.attributes.getNamedItem('title').value,
              image = img.attributes.getNamedItem('src').value,
              icon = image.substr(0, image.indexOf('?'));

          return { title: title, icon: icon };
        }
          return {};
      });
    } catch(e) {
      if(page)
        page.error(e);
      throw(e);
    }
  });
};


exports.getVOD = function(id, episode, page) {
  exports.call("getlink", {
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'Cookie': 'laravel_session=eyJpdiI6InlEd1wvZ1Rmdmd1VG9HTllEcE5majhBPT0iLCJ2YWx1ZSI6InN1V1BiWHRvWjZNd3pUNVdldGNpXC9MZlhIWllqY2dPSjhhZkUxcU5zSm1GdWdETVdhc0pTUkJuK0VuXC93a0xDT3RwUldDTVV5aTJEWENHZVlxUUVaZmc9PSIsIm1hYyI6IjNhZDNiMDNmYzYzMzEzODVmYThkMTIzNDkxM2U3Njg3ZmFjZTViM2UwZDM4NzRmNTFlMGUwOWRiOWJjMDQ0ZTkifQ%3D%3D;'
    },
    postdata: {
      id: id,
      episode: episode,
      type: 'newchannel',
      quality: 5,
      mobile: 'web'
    }
  }, page, function(item) {
    page.loading = false;
    page.type = 'video';
    var videoParams = {
      title: unescape(item.episode_name),
      icon: item.thumb,
      canonicalUrl: PREFIX + ':vod:' + id + ':' + episode,
      sources: [{
        url: item.stream
      }],
      no_subtitle_scan: 1
    };
    page.source = 'videoparams:' + JSON.stringify(videoParams);
  });
};
