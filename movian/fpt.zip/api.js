var http = require('movian/http');
var html = require('showtime/html');

exports.BASE_URL = 'https://fptplay.net';
exports.call = function(endpoint, params, page, cb) {
  var URL = exports.BASE_URL + '/show/' + endpoint;

  http.request(URL, params, function(err, result) {
    if(page)
      page.loading = false;
    if(err) {
      if(page)
        page.error(err);
    } else {
      try {
        var r = JSON.parse(result);
        if(r.error) {
          console.error("Request failed: " + URL);
          console.error(r.error.errors[0].message);
          if(page)
            page.error(r.error.errors[0].reason);
          throw(new Error("Request failed: " + r.error.errors[0].reason));
        }
        cb(r);
      } catch(e) {
        if(page)
          page.error(e);
        throw(e);
      }
    }
  });
}


exports.getChannelMap = function() {
  var dom = html.parse(http.request(exports.BASE_URL + '/livetv')),
    channels = dom.root.getElementByClassName('tv_channel'),
    tsChannels = dom.root.getElementByClassName('timeshift_channel').map(function(p) {
      return p.textContent;
    });
  
  return channels.reduce(function (map, ch) {
    var href = (ch.attributes.getNamedItem('data-href') || ch.attributes.getNamedItem('href')).value,
        dashes = href.split('/'),
        id = dashes[dashes.length - 1],
        title = ch.attributes.getNamedItem('title').value,
        image = ch.getElementByTagName('img')[0].attributes.getNamedItem('data-original').value,
        icon = image.substr(0, image.indexOf('?'));
    map[id] = { id: id, title: title, icon: icon, isTimeshift: tsChannels.indexOf(title) > -1 };
    return map;
  }, {});
}


exports.getLiveTV = function(ch, page) {
  exports.call("getlinklivetv", {
    headers: {
      'X-Requested-With': 'XMLHttpRequest'
    },
    postdata: {
      id: ch,
      type: 'newchannel',
      quality: 3,
      mobile: 'web'
    }
  }, page, function(info) {
    var videoParams = {
      title: unescape(info.name),
      icon: info.thumb,
      canonicalUrl: PREFIX + ':live:' + info._id,
      sources: [{ url: info.stream }],
      no_subtitle_scan: 1
    };
    page.appendItem('videoparams:' + JSON.stringify(videoParams), 'video', videoParams);
  });
}

exports.timeshift = function(id, page) {
  exports.call("timeshift", {
    headers: {
      'X-Requested-With': 'XMLHttpRequest'
    },
    postdata: {
      id: id,
      stream_id: 'bitrate_1000'
    }
  }, page, function(info) {
    page.loading = false;
    page.type = 'video';
    var videoParams = {
      // title: unescape(info.name),
      canonicalUrl: PREFIX + ':tvod:' + id,
      sources: [{
        url: info.stream
      }],
      no_subtitle_scan: 1
    }
    page.source = 'videoparams:' + JSON.stringify(videoParams);
    // print(page.source);
  });
}


exports.getVODs = function(catId, p) {
  var dom = html.parse(http.request(exports.BASE_URL + '/show/more',
    {
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      },
      postdata: {
        stucture_id: catId,
        type: 'new',
        page: p
      }
    })),
    movies = dom.root.getElementByTagName('a');
  
  return movies.map(function (a) {
    var href = a.attributes.getNamedItem('href').value,
        id = href.substring(href.lastIndexOf('-') + 1, href.lastIndexOf('.')),
        img = a.getElementByTagName('img')[0],
        title = img.attributes.getNamedItem('title').value,
        image = img.attributes.getNamedItem('src').value,
        icon = image.substr(0, image.indexOf('?'));
    return { id: id, title: title, icon: icon };
  });
}


exports.getEps = function(id, p) {
  var dom = html.parse(http.request(exports.BASE_URL + '/show/episode',
    {
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      },
      postdata: {
        film_id: id,
        page: p
      }
    })),
    eps = dom.root.getElementByTagName('li');
  
  return eps.map(function (li) {
    if (li.attributes.getNamedItem('rol')) {
      var ep = li.attributes.getNamedItem('rol').value,
          a = li.getElementByTagName('a')[0],
          img = li.getElementByTagName('img')[0],
          title = a.attributes.getNamedItem('title').value,
          image = img.attributes.getNamedItem('src').value,
          icon = image.substr(0, image.indexOf('?'));
      return { ep: ep, title: title, icon: icon };
    }
  });
}


exports.getVOD = function(id, episode, page) {
  exports.call("getlink", {
    headers: {
      'X-Requested-With': 'XMLHttpRequest'
    },
    postdata: {
      id: id,
      episode: episode,
      type: 'newchannel',
      quality: 5,
      mobile: 'web'
    }
  }, page, function(item) {
    page.loading = false;
    page.type = 'video';
    var videoParams = {
      title: unescape(item.episode_name),
      icon: item.thumb,
      canonicalUrl: PREFIX + ':vod:' + id + ':' + episode,
      sources: [{
        url: item.stream
      }],
      no_subtitle_scan: 1
    }
    page.source = 'videoparams:' + JSON.stringify(videoParams);
  });
}
